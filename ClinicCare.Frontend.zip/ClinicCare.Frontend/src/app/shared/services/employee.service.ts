import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, catchError, map, of } from 'rxjs';
import { environment } from '../../../environments/environment';
import { DoctorResponseDto, Employee } from '../models/employee.model';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/employees`;

  getEmployees(role?: 'Admin' | 'Doctor'): Observable<Employee[]> {
    let params = new HttpParams();
    if (role) {
      params = params.set('role', role);
    }

    return this.http
      .get<Employee[]>(this.baseUrl, { params })
      .pipe(catchError(() => of([])));
  }

  getDoctors(specializationId?: string) {
    let params = new HttpParams();

    if (specializationId) {
      params = params.set('specializationId', specializationId);
    }

    return this.http
      .get<DoctorResponseDto[]>(`${this.baseUrl}/doctor-details`, { params })
      .pipe(catchError(() => of([])));
  }

  getById(id: string): Observable<Employee> {
    return this.http.get<Employee>(`${this.baseUrl}/${id}`);
  }

  update(id: string, employee: Partial<Employee>): Observable<Employee> {
    return this.http.patch<Employee>(`${this.baseUrl}/${id}`, employee);
  }

  delete(id: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
